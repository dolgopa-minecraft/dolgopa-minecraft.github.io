RU: Спасибо за скачивание карты Долгопрудного!
Автор карты: Владимир Аксенов (SeviyMan)
Сайт проекта: https://dolgopa-minecraft.github.io/

== Установка ==
1. Откройте папку .minecraft/saves (как её найти - описано ниже)
2. Распакуйте папку Dolgoprudny Map из архива в saves
3. Откройте игру и выберите карту в списке миров

Если вы видите на табличках текст вроде dolgopa.sign1.line1, а вместо разметки на дорогах - случайные блоки, проверьте наличие в папке мира файла resources.zip.
При его отсутствии скопируйте из архива файл dologpack-res1.21.zip в папку мира под названием resources.zip.

Для игры с друзьями по сети им так же потребуется дополнительно установить ресурс-пак. Отправьте друзьям dolgopack-res1.21.zip. Они должны положить его в
папку .minecraft/resourcepacks, после чего активировать набор ресурсов в настройках игры в соответствующем разделе.

== Как найти папку .minecraft ==
Вообще, во многих лаунчерах есть кнопка с иконкой папки или подобной, открывающей папку с игрой. Но если вдруг такой кнопки нет, то вот как самостоятельно найти директорию:
= Windows =
%APPDATA%\.minecraft
Нажмите Win+R. В появившемся окне введите %appdata% и нажмите ОК. В открывшейся папке перейдите в .minecraft.

= macOS =
~/Library/Application Support/minecraft
Откройте поиск Spotlight, нажав на иконку лупы в правом части верхней панели. Вставьте в поисковую строку ~/Library/Application Support/minecraft и нажмите Enter.

= Linux =
~/.minecraft
В разных дистрибутивах поиск директории может осуществляться по-разному. Символ ~ означает домашнюю директорию, то есть /home/user.


EN: Thank you for downloading the Dolgoprudny map!
Made by: Vladimir Aksenov (SeviyMan)
Project website: https://dolgopa-minecraft.github.io/

== Installation ==
1. Open the .minecraft/saves folder (how to find it is described below)
2. Unzip the Dolgoprudny Map folder from the archive to saves folder
3. Open the game and select the map in the world list

If you see text like dolgopa.sign1.line1 on the signs, and random blocks instead of road markings, check for the presence of the resources.zip file in the world folder.
If it is not there, copy the dologpack-res1.21.zip file from the archive to the world folder and rename it to resources.zip.

To play with friends online, they will also need to additionally install the resource pack. Send your friends dolgopack-res1.21.zip. They should put it in the
.minecraft/resourcepacks folder, and then activate the resource pack in the game settings in the corresponding section.

== How to find the .minecraft folder ==
In general, many launchers have a button with a folder icon or something similar that opens the game folder. But if suddenly there is no such button, then here's how to find the directory yourself:
= Windows =
%APPDATA%\.minecraft
Press Win+R. In the window that appears, enter %appdata% and click OK. In the folder that opens, go to .minecraft.

= macOS =
~/Library/Application Support/minecraft
Open Spotlight search by clicking on the magnifying glass icon on the right side of the top panel. Paste ~/Library/Application Support/minecraft into the search bar and press Enter.

= Linux =
~/.minecraft
Different distributions may search for the directory in different ways. The ~ symbol stands for the home directory, i.e. /home/user.